async function r() {
  await h(), c(), s(), await o();
}
function c() {
  chrome.tabs.onActivated.addListener(async ({ tabId: t }) => {
    await u(t);
  }), chrome.tabs.onUpdated.addListener(async (t, n, e) => {
    n.status === "complete" && await l(t, e);
  });
}
function s() {
  chrome.runtime.onMessage.addListener((t, n, e) => (d(t, n).then(e), !0));
}
async function o() {
  await f() && await i();
}
async function u(t) {
  await b(t) && await i();
}
async function l(t, n) {
  a(t, n), await i();
}
async function d(t, n) {
  return console.log("Runtime message:", t, n), null;
}
async function f() {
  const [t] = await chrome.tabs.query({
    active: !0,
    currentWindow: !0
  });
  return t?.id === void 0 || !t.url ? null : a(t.id, t);
}
async function b(t) {
  const n = await chrome.tabs.get(t);
  return n.url ? a(t, n) : null;
}
function a(t, n) {
  return {
    id: t,
    url: n.url ?? "",
    title: n.title ?? ""
  };
}
async function i(t) {
}
async function h() {
}
r().catch((t) => {
  console.error("[Filter/Search] Extension initialization failed", t);
});
